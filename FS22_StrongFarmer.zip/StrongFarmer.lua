StrongFarmer = {}

Player.MAX_PICKABLE_OBJECT_MASS = 100 -- 100 tons
Player.MAX_PICKABLE_OBJECT_DISTANCE = 15 -- 15 meters

function StrongFarmer:loadMap(name)
end

function StrongFarmer:deleteMap()
end

function StrongFarmer:mouseEvent()
end

function StrongFarmer:keyEvent()
end

function StrongFarmer:update()
end

function StrongFarmer:draw()
end

-- The pickup behaviour of vehicles in FS22 seems to have changed compared to FS19, so we need to override it.
function Vehicle:getCanBePickedUp(ply)
	local ownerId = self:getOwnerFarmId()
	if not ply.farmId or not ownerId then
		return self:getTotalMass() <= Player.MAX_PICKABLE_OBJECT_MASS
	end

    return ply.farmId == ownerId
end

addModEventListener(StrongFarmer)